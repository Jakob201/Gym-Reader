# Gym-Reader
This a little tracker of mine, to keep my gym schedule. It works kinda like a reward system, where you get points for push ups and hours in the gym.
This points you can trade for reading a chapter of a book and when you want to read a new book.
kinda nerdy i know XD
